# Build and verification status

- Original supplied Android project retained as the base; the existing TelexEngine was preserved.
- Offline Japanese engine compiled independently with Kotlin 1.9 and passed 11 Japanese conversion/candidate smoke assertions.
- Existing Vietnamese Telex engine compiled independently with Kotlin 1.9 and passed 3 smoke assertions.
- JUnit 4 unit tests and a GitHub Actions Android build workflow are included.
- Manifest checked: no `INTERNET` permission; Android backup disabled.
- A full Android APK build was **not run in the current environment** because Android SDK / Gradle are not installed here. Run the included workflow or build in Android Studio before distributing an APK.

The bundled Japanese Kanji lexicon is deliberately a modest offline starter dictionary, not a complete contextual Japanese conversion engine. See README for details.
