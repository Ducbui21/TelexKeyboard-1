# Telex Keyboard — Việt / 日本語 / English

A native Android Input Method Editor (IME) based on the supplied Telex Keyboard source.

## Included
- Vietnamese Telex composition, sentence capitalization and local correction suggestions.
- Japanese Romaji-to-Hiragana conversion, Hiragana/Katakana toggle, small-tsu, syllabic `n`, common yōon and foreign-sound combinations.
- A small built-in Japanese candidate lexicon for common words (for example 日本語, 東京, 学校, 今日, 私). Candidate selection is local.
- English direct typing, emoji page, current Android clipboard page, number row, symbols page and iPhone-inspired key styling.
- Locally stored accent color and key-height preferences.

## Build
Open this folder in Android Studio with JDK 17 and Android Gradle Plugin 8.5.2 / Gradle 8.7. Or run `gradle testDebugUnitTest assembleDebug` with Android SDK platform 34 and build-tools 34.0.0 installed. A GitHub Actions workflow is included to run unit tests and publish the debug APK artifact.

## Enable the keyboard
1. Install the generated `app-debug.apk`.
2. Open Telex Keyboard and enable it in Android's input-method settings.
3. Select Telex Keyboard from the input-method picker.
4. The language key cycles Vietnamese → Japanese → English. Japanese input uses Romaji; Space advances through available local candidates, and tapping a candidate commits it.
5. Tap あ / ア to switch Hiragana / Katakana. The emoji and clipboard toolbar keys open their respective pages.

## Offline and privacy
The app declares no `INTERNET` permission. Text conversion and candidate lookup run locally. Backup is disabled. The clipboard page reads the device's current primary clipboard only when opened; it is not a persistent clipboard history. As with any third-party keyboard, the IME necessarily processes text typed into the focused field. Do not install builds from untrusted sources.

## Japanese dictionary scope
The included Romaji converter covers common kana combinations, but the bundled Kanji candidate lexicon is intentionally small and curated. It is **not** a full-scale Japanese IME and cannot provide comprehensive context-aware Kanji conversion or predictive learning. A genuinely comprehensive offline Japanese IME requires bundling a properly licensed dictionary and conversion engine (for example a compatible Mozc-based stack), which is a substantially larger integration and licensing task. The project does not claim otherwise.
