package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Test

class TelexEngineTest {
    @Test fun composesVietnameseTelex() {
        assertEquals("Việt", TelexEngine.compose("Vieetj"))
        assertEquals("đ", TelexEngine.compose("dd"))
        assertEquals("ă", TelexEngine.compose("aw"))
    }
}
