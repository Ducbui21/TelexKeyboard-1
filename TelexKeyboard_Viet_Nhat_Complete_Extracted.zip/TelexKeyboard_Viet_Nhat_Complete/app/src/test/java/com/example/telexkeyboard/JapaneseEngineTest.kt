package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class JapaneseEngineTest {
    @Test fun convertsCommonRomaji() {
        assertEquals("こんにちは", JapaneseEngine.convert("konnichiwa").kana)
        assertEquals("こんばんは", JapaneseEngine.convert("konbanwa").kana)
        assertEquals("にほんご", JapaneseEngine.convert("nihongo").kana)
        assertEquals("ありがとう", JapaneseEngine.convert("arigatou").kana)
    }
    @Test fun retainsIncompleteSyllable() {
        val result = JapaneseEngine.convert("ka")
        assertEquals("か", result.kana)
        assertEquals("", result.pending)
        assertEquals("k", JapaneseEngine.convert("k").pending)
    }
    @Test fun handlesSmallTsuAndN() {
        assertEquals("がっこう", JapaneseEngine.convert("gakkou").kana)
        assertEquals("かんじ", JapaneseEngine.convert("kanji").kana)
    }
    @Test fun convertsKanaToKatakana() {
        assertEquals("コンニチハ", JapaneseEngine.katakana("こんにちは"))
    }
    @Test fun providesLocalKanjiCandidates() {
        assertTrue(JapaneseEngine.candidates("にほんご").contains("日本語"))
    }
}
