package com.example.telexkeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("keyboard", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad,pad*2,pad,pad) }
        root.addView(TextView(this).apply { text = "Telex Keyboard · Việt / 日本語 / English\nGõ tiếng Nhật bằng Romaji; Space để xem/chọn gợi ý."; textSize=18f })
        root.addView(Button(this).apply { text="1. Bật bàn phím trong Cài đặt"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
        root.addView(Button(this).apply { text="2. Chọn bàn phím Telex"; setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
        root.addView(TextView(this).apply { text="Chiều cao bàn phím: ${prefs.getInt("height",44)} dp"; textSize=16f })
        root.addView(SeekBar(this).apply { max=22; progress=prefs.getInt("height",44)-36; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { (root.getChildAt(3) as TextView).text="Chiều cao bàn phím: ${progress+36} dp" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) { prefs.edit().putInt("height",(seekBar?.progress ?: 8)+36).apply() }
        }) })
        root.addView(TextView(this).apply { text="Màu bàn phím (chọn nhanh)"; textSize=16f })
        root.addView(LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            listOf("Mặc định","Xanh","Tím","Hồng").forEachIndexed { i,label -> addView(Button(this@MainActivity).apply { text=label; setOnClickListener { prefs.edit().putInt("accent",i).apply() } }, LinearLayout.LayoutParams(0,-2,1f)) }
        })
        root.addView(TextView(this).apply { text="Riêng tư: không có quyền Internet; chuyển đổi chạy trên máy. Clipboard hiển thị nội dung clipboard hiện tại, không lưu lịch sử. Từ điển Kanji offline là bộ từ thông dụng có giới hạn, chưa thay thế được IME Nhật chuyên dụng."; textSize=13f })
        root.addView(EditText(this).apply { hint="Gõ thử: Vieetj Nam / nihongo / arigatou" })
        setContentView(root)
    }
}
