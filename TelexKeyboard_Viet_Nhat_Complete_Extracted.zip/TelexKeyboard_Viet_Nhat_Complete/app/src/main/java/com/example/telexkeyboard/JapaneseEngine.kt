package com.example.telexkeyboard

/**
 * Offline Japanese input core: standard Hepburn/Kunrei-style Romaji -> Hiragana,
 * Katakana conversion and a small built-in candidate lexicon.
 * No network access, telemetry, or user-text persistence.
 */
object JapaneseEngine {
    private val romajiToKana: Map<String, String> = buildMap {
        val rows = mapOf(
            "" to listOf("あ=a", "い=i", "う=u", "え=e", "お=o"),
            "k" to listOf("か=ka", "き=ki", "く=ku", "け=ke", "こ=ko"),
            "s" to listOf("さ=sa", "し=shi si", "す=su", "せ=se", "そ=so"),
            "t" to listOf("た=ta", "ち=chi ti", "つ=tsu tu", "て=te", "と=to"),
            "n" to listOf("な=na", "に=ni", "ぬ=nu", "ね=ne", "の=no"),
            "h" to listOf("は=ha", "ひ=hi", "ふ=fu hu", "へ=he", "ほ=ho"),
            "m" to listOf("ま=ma", "み=mi", "む=mu", "め=me", "も=mo"),
            "y" to listOf("や=ya", "ゆ=yu", "よ=yo"),
            "r" to listOf("ら=ra", "り=ri", "る=ru", "れ=re", "ろ=ro"),
            "w" to listOf("わ=wa", "を=wo"),
            "g" to listOf("が=ga", "ぎ=gi", "ぐ=gu", "げ=ge", "ご=go"),
            "z" to listOf("ざ=za", "じ=ji zi", "ず=zu", "ぜ=ze", "ぞ=zo"),
            "d" to listOf("だ=da", "ぢ=di", "づ=du", "で=de", "ど=do"),
            "b" to listOf("ば=ba", "び=bi", "ぶ=bu", "べ=be", "ぼ=bo"),
            "p" to listOf("ぱ=pa", "ぴ=pi", "ぷ=pu", "ぺ=pe", "ぽ=po")
        )
        rows.values.flatten().forEach { row ->
            val parts = row.split('=')
            val kana = parts[0]
            parts[1].split(' ').forEach { put(it, kana) }
        }
        listOf(
            "きゃ=kya", "きゅ=kyu", "きょ=kyo", "しゃ=sha sya", "しゅ=shu syu", "しょ=sho syo",
            "ちゃ=cha tya", "ちゅ=chu tyu", "ちょ=cho tyo", "にゃ=nya", "にゅ=nyu", "にょ=nyo",
            "ひゃ=hya", "ひゅ=hyu", "ひょ=hyo", "みゃ=mya", "みゅ=myu", "みょ=myo",
            "りゃ=rya", "りゅ=ryu", "りょ=ryo", "ぎゃ=gya", "ぎゅ=gyu", "ぎょ=gyo",
            "じゃ=ja zya", "じゅ=ju zyu", "じょ=jo zyo", "びゃ=bya", "びゅ=byu", "びょ=byo",
            "ぴゃ=pya", "ぴゅ=pyu", "ぴょ=pyo",
            "うぃ=wi", "うぇ=we", "うぉ=who", "ふぁ=fa", "ふぃ=fi", "ふぇ=fe", "ふぉ=fo",
            "てぃ=thi", "でぃ=dhi", "とぅ=twu", "どぅ=dwu", "しぇ=she", "じぇ=je",
            "ちぇ=che", "つぁ=tsa", "つぃ=tsi", "つぇ=tse", "つぉ=tso"
        ).forEach { row ->
            val parts = row.split('=')
            parts[1].split(' ').forEach { put(it, parts[0]) }
        }
    }

    // Curated local candidates. This is intentionally transparent and extendable;
    // it is not presented as a full JMdict/Mozc replacement.
    private val lexicon: Map<String, List<String>> = mapOf(
        "わたし" to listOf("私"), "ぼく" to listOf("僕"), "おれ" to listOf("俺"),
        "にほん" to listOf("日本"), "にほんご" to listOf("日本語"), "とうきょう" to listOf("東京"),
        "おおさか" to listOf("大阪"), "きょう" to listOf("今日"), "あした" to listOf("明日"), "きのう" to listOf("昨日"),
        "いま" to listOf("今"), "じかん" to listOf("時間"), "とき" to listOf("時"),
        "がっこう" to listOf("学校"), "せんせい" to listOf("先生"), "がくせい" to listOf("学生"),
        "ともだち" to listOf("友達"), "かぞく" to listOf("家族"), "かいしゃ" to listOf("会社"),
        "でんしゃ" to listOf("電車"), "くるま" to listOf("車"), "えき" to listOf("駅"),
        "ねこ" to listOf("猫"), "いぬ" to listOf("犬"), "とり" to listOf("鳥"), "さかな" to listOf("魚"),
        "みず" to listOf("水"), "ひ" to listOf("火"), "やま" to listOf("山"), "かわ" to listOf("川"),
        "あめ" to listOf("雨"), "ゆき" to listOf("雪"), "はな" to listOf("花"), "き" to listOf("木"),
        "たべる" to listOf("食べる"), "のみます" to listOf("飲みます"), "いく" to listOf("行く"),
        "くる" to listOf("来る"), "みる" to listOf("見る"), "きく" to listOf("聞く", "効く"),
        "おいしい" to listOf("美味しい"), "たのしい" to listOf("楽しい"), "うれしい" to listOf("嬉しい"),
        "げんき" to listOf("元気"), "ありがとう" to listOf("有難う"), "こんにちは" to listOf("今日は"),
        "こんばんは" to listOf("今晩は"), "おはよう" to listOf("お早う"), "すみません" to listOf("済みません"),
        "お願いします" to listOf("お願いします"), "べんきょう" to listOf("勉強"), "しごと" to listOf("仕事"),
        "でんわ" to listOf("電話"), "てんき" to listOf("天気"), "せかい" to listOf("世界"),
        "あい" to listOf("愛"), "ゆめ" to listOf("夢"), "こころ" to listOf("心"),
        "おかね" to listOf("お金"), "もの" to listOf("物"), "こと" to listOf("事"),
        "ひと" to listOf("人"), "こども" to listOf("子供"), "おとな" to listOf("大人")
    )

    data class Result(val kana: String, val pending: String)

    /** Convert as much Romaji as possible, retaining an incomplete suffix for the next keystroke. */
    fun convert(input: String): Result {
        val normalized = input.lowercase()
        // Conventional fixed spellings are commonly entered phonetically even
        // though the final particle is written with は, not わ.
        when (normalized) {
            "konnichiwa" -> return Result("こんにちは", "")
            "konbanwa" -> return Result("こんばんは", "")
        }
        var rest = normalized
        val out = StringBuilder()
        while (rest.isNotEmpty()) {
            if (rest.startsWith("n'")) { out.append('ん'); rest = rest.drop(2); continue }
            if (rest.startsWith("nn")) {
                if (rest.length >= 3 && rest[2] in "aiueoy") { out.append('ん'); rest = rest.drop(1) }
                else { out.append('ん'); rest = rest.drop(2) }
                continue
            }
            if (rest.length >= 2 && rest[0] == rest[1] && rest[0] in "bcdfghjklmpqrstvwxyz" && rest[0] != 'n') {
                out.append('っ'); rest = rest.drop(1); continue
            }
            if (rest.startsWith("n") && rest.length >= 2 && rest[1] !in "aiueoyn'") {
                out.append('ん'); rest = rest.drop(1); continue
            }
            val match = romajiToKana.keys.asSequence()
                .filter { rest.startsWith(it) }
                .maxByOrNull { it.length }
            if (match != null) { out.append(romajiToKana.getValue(match)); rest = rest.drop(match.length); continue }
            if (romajiToKana.keys.any { it.startsWith(rest) }) break
            val c = rest.first()
            if (c in 'a'..'z') out.append(c) else out.append(c)
            rest = rest.drop(1)
        }
        return Result(out.toString(), rest)
    }

    fun katakana(value: String): String = buildString(value.length) {
        value.forEach { c -> append(if (c in '\u3041'..'\u3096') (c.code + 0x60).toChar() else c) }
    }

    fun candidates(kana: String): List<String> = listOf(kana) + (lexicon[kana] ?: emptyList())
}
